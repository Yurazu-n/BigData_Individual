package org.example;

import org.openjdk.jmh.annotations.*;

import java.util.Random;
import java.util.concurrent.TimeUnit;

@BenchmarkMode(Mode.AverageTime)
@OutputTimeUnit(TimeUnit.MILLISECONDS)
@State(Scope.Benchmark)
@Warmup(iterations = 10, time = 1, timeUnit = TimeUnit.SECONDS)
@Measurement(iterations = 10, time = 1, timeUnit = TimeUnit.SECONDS)
@Fork(5)
public class MatrixBenchmark {

    // Parametrizamos el tamaño de la matriz
    @Param({"256", "512", "1000"}) // Puedes añadir más tamaños si lo necesitas
    public int n;

    double[][] a;
    double[][] b;
    double[][] c;

    @Setup(Level.Trial)
    public void setup() {
        // Inicializar matrices con el tamaño 'n' para cada prueba
        a = new double[n][n];
        b = new double[n][n];
        c = new double[n][n];

        // Llenar las matrices con valores aleatorios
        Random random = new Random();
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                a[i][j] = random.nextDouble();
                b[i][j] = random.nextDouble();
                c[i][j] = 0;
            }
        }
    }

    @Benchmark
    public void testMatrixMultiplication() {
        // Multiplicación de matrices
        for (int i = 0; i < n; i++) {
            for (int j = 0; j < n; j++) {
                for (int k = 0; k < n; k++) {
                    c[i][j] += a[i][k] * b[k][j];
                }
            }
        }
    }
}
